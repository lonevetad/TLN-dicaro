
Per poter eseguire il codice della rete neurale, effettuate i seguenti passi

1) installate python 3.5 o superiore
2) aprite un terminale ed andate nella cartella in cui avete messo il codice
3) eseguite il comando "pip3 install -r requirements.txt" per installare le dipendenze
(usate pip3 se avete sia python 2.7 che python 3.5+, altrimenti usate pip)

Una volta installate le dipendenze, potete avviare la rete neurale. Per far questo, vi basta
eseguire il comando "python3 model.py" o eseguirlo da IDE

Il file beam_search.py contiene lo script per questo metodo di decoding. Lo script è da completare (esercizio)

Il file create_train_file.py contiene lo script per creare il file train.bin
